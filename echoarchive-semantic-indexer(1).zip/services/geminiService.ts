
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { StructuralSegment, HumanReviewStatus } from "../types";

export interface ArchivalAnalysisResult {
  segments: StructuralSegment[];
  temporal_index: string;
  description: string;
}

const cleanJsonString = (str: string): string => {
  return str.replace(/```json\n?/, '').replace(/\n?```/, '').trim();
};

/**
 * Robust transcription logic. 
 * Attempts ElevenLabs Scribe first (if key provided), 
 * falls back to Gemini-native transcription if ElevenLabs fails or is unconfigured.
 */
export const transcribeAudio = async (blob: Blob, userKey?: string | null): Promise<string> => {
  const elevenLabsKey = (process.env as any).ELEVENLABS_API_KEY || userKey;
  
  // Try ElevenLabs if a key is present
  if (elevenLabsKey && elevenLabsKey.startsWith('sk_')) {
    try {
      const formData = new FormData();
      formData.append('file', blob, 'audio.wav');
      formData.append('model_id', 'scribe_v1');
      
      const response = await fetch('https://api.elevenlabs.io/v1/speech-to-text', {
        method: 'POST',
        headers: { 'xi-api-key': elevenLabsKey },
        body: formData
      });

      if (response.ok) {
        const data = await response.json();
        if (data.text) return data.text;
      } else {
        const err = await response.json();
        console.warn("ElevenLabs STT Error Response:", err);
      }
    } catch (err) {
      console.warn("ElevenLabs STT Request Failed (likely CORS or network):", err);
    }
  }

  // Fallback: Gemini-native transcription
  console.log("Falling back to Gemini for transcription...");
  return transcribeWithGemini(blob);
};

/**
 * Gemini-native transcription as a primary or fallback layer.
 */
export const transcribeWithGemini = async (blob: Blob): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const model = "gemini-3-flash-preview"; 

  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = (reader.result as string).split(',')[1];
      try {
        const response = await ai.models.generateContent({
          model: model,
          contents: {
            parts: [
              { inlineData: { mimeType: blob.type || 'audio/wav', data: base64 } },
              { text: "Transcribe the following audio recording exactly as spoken. Focus on accuracy for names, places, and musical terms. Output the text only." }
            ]
          }
        });
        resolve(response.text || "No speech detected by Gemini.");
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
};

/**
 * Performs deep semantic indexing using Gemini with a strict archival role.
 */
export const suggestArchivalSegments = async (
  base64Audio: string, 
  mimeType: string, 
  transcript: string,
  durationSeconds: number
): Promise<ArchivalAnalysisResult> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const modelName = "gemini-3-pro-preview";

  const response = await ai.models.generateContent({
    model: modelName,
    contents: {
      parts: [
        { inlineData: { mimeType: mimeType, data: base64Audio } },
        {
          text: `SYSTEM / ROLE
You are an archival audio segmentation engine for traditional music collections. Your job is to produce a consistent, machine-readable timeline and a formal Finding Aid.

TEMPORAL_INDEX FORMAT (Strictly follow this for 'temporal_index'):
HH:MM:SS - HH:MM:SS | Title, Type / Performer, Instrument
Example:
00:00:13 - 00:00:57 | The torn jacket, reel / Mike McHale, flute
00:00:57 - 00:01:23 | The green gates, reel / Various performers, instrumental music

HARD RULES
1) Output JSON ONLY.
2) COMPLETE coverage: 0.0 to ${durationSeconds.toFixed(2)}.
3) No gaps, no overlaps.
4) Times in seconds (2 decimal places) for the segment objects.
5) Labels: "Speech", "Tune", "Song", "Silence", "Other".

INPUTS
- DURATION: ${durationSeconds.toFixed(2)}s
- TRANSCRIPT: "${transcript}"`
        }
      ]
    },
    config: {
      thinkingConfig: { thinkingBudget: 32768 },
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          segments: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                start_time: { type: Type.NUMBER },
                end_time: { type: Type.NUMBER },
                type: { type: Type.STRING, enum: ["Speech", "Tune", "Song", "Silence", "Other"] },
                summary: { type: Type.STRING },
                confidence: { type: Type.NUMBER },
                segment_metadata: {
                  type: Type.OBJECT,
                  properties: {
                    tune_type: { type: Type.STRING },
                    meter: { type: Type.STRING },
                    tempo_bpm_range: { type: Type.ARRAY, items: { type: Type.NUMBER } },
                    instruments: { type: Type.ARRAY, items: { type: Type.STRING } },
                    region: { type: Type.STRING },
                    performers: { type: Type.ARRAY, items: { type: Type.STRING } },
                    evidence: { type: Type.ARRAY, items: { type: Type.STRING } },
                    notes: { type: Type.STRING }
                  },
                  required: ["evidence"]
                }
              },
              required: ["start_time", "end_time", "type", "summary", "confidence"]
            }
          },
          temporal_index: { type: Type.STRING },
          description: { type: Type.STRING }
        },
        required: ["segments", "temporal_index", "description"]
      }
    }
  });

  try {
    const rawText = response.text || "";
    const sanitizedText = cleanJsonString(rawText);
    const rawData = JSON.parse(sanitizedText);
    
    const now = new Date().toISOString();
    const segments = (rawData.segments || []).map((s: any, i: number): StructuralSegment => ({
      ...s,
      id: `ai-seg-${i}-${Date.now()}`,
      provenance: {
        generated_by: modelName,
        generated_at: now,
        generation_method: "Archival Segmentation Engine v2.1",
        human_review_status: "unreviewed"
      }
    }));

    return {
      segments: segments.sort((a: any, b: any) => a.start_time - b.start_time),
      temporal_index: rawData.temporal_index || "Index generation failed.",
      description: rawData.description || "Narrative abstract generation failed."
    };
  } catch (err) {
    throw new Error("Analysis cycle failed.");
  }
};

/**
 * Narrates the archival summary using ElevenLabs or Gemini fallback.
 */
export const generateArchivalNarrative = async (text: string, userKey?: string | null): Promise<string> => {
  const elevenLabsKey = (process.env as any).ELEVENLABS_API_KEY || userKey;

  if (elevenLabsKey && elevenLabsKey.startsWith('sk_')) {
    try {
      const voiceId = "pNInz6obpg8ndclQU7xa"; // Professional Narrator
      const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'xi-api-key': elevenLabsKey,
        },
        body: JSON.stringify({
          text,
          model_id: 'eleven_monolingual_v1',
          voice_settings: { stability: 0.6, similarity_boost: 0.75 }
        }),
      });

      if (response.ok) {
        const blob = await response.blob();
        return new Promise((resolve) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
          reader.readAsDataURL(blob);
        });
      }
    } catch (err) {
      console.warn("ElevenLabs TTS Failed, falling back...");
    }
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const ttsResponse = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text: `In a professional archival voice, narrate: ${text}` }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Charon' } },
      },
    },
  });

  const base64Audio = ttsResponse.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) throw new Error("Voice synthesis cycle failed.");
  return base64Audio;
};

export function decodeBase64(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

export async function decodeAudioBuffer(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number = 24000,
  numChannels: number = 1
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}
