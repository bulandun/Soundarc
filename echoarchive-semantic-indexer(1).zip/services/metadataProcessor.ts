
import { ArchivalAudioItem, StructuralSegment } from '../types';

export const validateArchivalItem = (item: ArchivalAudioItem): string[] => {
  const errors: string[] = [];

  // Required Descriptive
  if (!item.descriptive.identifier) errors.push("Identifier is required (e.g., ITMA_2026_0145)");
  if (!item.descriptive.title) errors.push("Title is required");

  // Required Technical
  if (!item.technical.checksum) errors.push("SHA-256 Checksum is required for archival integrity");
  if (item.technical.sample_rate_hz <= 0) errors.push("Invalid sample rate");

  // Structural Integrity
  item.structural.segments.forEach((seg, idx) => {
    if (seg.start_time >= seg.end_time) {
      errors.push(`Segment ${idx + 1}: Start time must be before end time.`);
    }
    // Check for overlaps
    const nextSeg = item.structural.segments[idx + 1];
    if (nextSeg && seg.end_time > nextSeg.start_time) {
      errors.push(`Overlapping segments detected between ${seg.id} and ${nextSeg.id}.`);
    }
  });

  return errors;
};

/**
 * Stub for mapping to BWF fields. 
 * Real implementation would use a library like 'bwf-writer' or 'exiftool-vendored'
 */
export const getBWFMapping = (item: ArchivalAudioItem) => {
  return {
    Description: item.descriptive.description,
    // Fix: Using 'creator' instead of 'creators' as defined in DescriptiveMetadata
    Originator: item.descriptive.creator,
    OriginatorReference: item.descriptive.identifier,
    // Fix: Using 'date' instead of 'date_recorded' as defined in DescriptiveMetadata
    OriginationDate: item.descriptive.date || '',
    TimeReference: 0,
    Version: 1,
    UMID: '',
    CodingHistory: `A=PCM,F=${item.technical.sample_rate_hz},W=${item.technical.bit_depth},M=${item.technical.channels === 1 ? 'mono' : 'stereo'}`,
    iXML: {
      PROJECT: item.descriptive.title,
      SCENE: item.descriptive.identifier,
      // Fix: Using 'coverage' instead of 'location' as defined in DescriptiveMetadata
      TAPE: item.descriptive.coverage || '',
      CIRCULATED_DESC: item.administrative.license
    }
  };
};

export const formatDuration = (seconds: number): string => {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  const ms = Math.floor((seconds % 1) * 1000);
  return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}.${ms.toString().padStart(3, '0')}`;
};
