
import React, { useEffect, useRef, useState, useMemo } from 'react';
import { AudioSegment } from '../types';

interface TimelineProps {
  segments: AudioSegment[];
  duration: number;
  currentTime: number;
  onSeek: (time: number) => void;
  selectedSegmentId: string | null;
  onSelectSegment: (id: string) => void;
  audioUrl?: string | null;
}

const Timeline: React.FC<TimelineProps> = ({
  segments,
  duration,
  currentTime,
  onSeek,
  selectedSegmentId,
  onSelectSegment,
  audioUrl
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [waveform, setWaveform] = useState<number[]>([]);
  const progress = (currentTime / duration) * 100;

  const formatTimeShort = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  useEffect(() => {
    if (!audioUrl) return;

    const generateWaveform = async () => {
      try {
        const response = await fetch(audioUrl);
        const arrayBuffer = await response.arrayBuffer();
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const audioBuffer = await audioCtx.decodeAudioData(arrayBuffer);
        
        const rawData = audioBuffer.getChannelData(0);
        const samples = 150;
        const blockSize = Math.floor(rawData.length / samples);
        const filteredData = [];
        for (let i = 0; i < samples; i++) {
          let blockStart = blockSize * i;
          let sum = 0;
          for (let j = 0; j < blockSize; j++) {
            sum = sum + Math.abs(rawData[blockStart + j]);
          }
          filteredData.push(sum / blockSize);
        }
        
        const multiplier = Math.pow(Math.max(...filteredData), -1);
        setWaveform(filteredData.map(n => n * multiplier));
      } catch (e) {
        setWaveform(Array.from({length: 150}, () => Math.random() * 0.5 + 0.1));
      }
    };

    generateWaveform();
  }, [audioUrl]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || waveform.length === 0) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    canvas.width = canvas.offsetWidth * dpr;
    canvas.height = canvas.offsetHeight * dpr;
    ctx.scale(dpr, dpr);

    const width = canvas.offsetWidth;
    const height = canvas.offsetHeight;
    const barWidth = width / waveform.length;
    
    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = 'rgba(79, 70, 229, 0.45)';

    waveform.forEach((val, i) => {
      const barHeight = val * height * 0.7;
      const x = i * barWidth;
      const y = (height - barHeight) / 2;
      ctx.beginPath();
      ctx.roundRect(x + 1, y, barWidth - 2, barHeight, 2);
      ctx.fill();
    });
  }, [waveform]);

  const milestones = useMemo(() => {
    return segments.map(s => ({
      time: formatTimeShort(s.startTime),
      label: s.label
    }));
  }, [segments]);

  return (
    <div className="space-y-4">
      <div className="relative w-full h-40 bg-slate-900/95 rounded-[2.5rem] overflow-hidden group shadow-2xl border-2 border-white/5">
        <canvas 
          ref={canvasRef} 
          className="absolute inset-0 w-full h-full opacity-30 pointer-events-none" 
        />

        <div className="absolute inset-0 pt-6 pb-14">
          {segments.map((seg) => {
            const left = (seg.startTime / duration) * 100;
            const width = ((seg.endTime - seg.startTime) / duration) * 100;
            const isSelected = selectedSegmentId === seg.id;

            const baseColorClass = 
              seg.category === 'music' ? 'emerald' :
              seg.category === 'speech' ? 'amber' :
              'indigo';

            return (
              <div
                key={seg.id}
                className={`absolute h-24 rounded-2xl border-2 cursor-pointer transition-all duration-500 overflow-hidden flex flex-col justify-start p-4
                  ${seg.category === 'music' ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300' :
                    seg.category === 'speech' ? 'bg-amber-500/10 border-amber-500/30 text-amber-300' :
                    'bg-indigo-500/10 border-indigo-500/30 text-indigo-300'}
                  ${isSelected ? 'ring-4 ring-white/10 border-white/90 z-10 shadow-2xl scale-[1.02] bg-white/5' : 'z-0 backdrop-blur-[2px] hover:bg-white/5'}
                `}
                style={{ left: `${left}%`, width: `${width}%`, minWidth: '100px' }}
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectSegment(seg.id);
                  onSeek(seg.startTime);
                }}
              >
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[10px] font-black tabular-nums bg-black/60 px-2 py-0.5 rounded border border-white/10">
                    {formatTimeShort(seg.startTime)}
                  </span>
                  <span className="text-[9px] font-black uppercase tracking-[0.2em] opacity-50">
                    {seg.label}
                  </span>
                </div>
                <div className="text-[10px] font-bold tracking-tight leading-tight line-clamp-3 text-white/80">
                  {seg.metadata.description}
                </div>
                
                <div className={`absolute top-0 left-0 right-0 h-1 
                  ${seg.category === 'music' ? 'bg-emerald-400' : 
                    seg.category === 'speech' ? 'bg-amber-400' : 
                    'bg-indigo-400'}`} 
                />
              </div>
            );
          })}
        </div>

        <div 
          className="absolute top-0 bottom-0 w-0.5 bg-white z-20 pointer-events-none transition-all duration-75 mix-blend-difference"
          style={{ left: `${progress}%` }}
        >
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-4 h-4 bg-white rounded-full shadow-[0_0_20px_rgba(255,255,255,0.8)] border-4 border-indigo-600"></div>
        </div>

        <div 
          className="absolute inset-0 z-30 cursor-pointer"
          onClick={(e) => {
            const rect = e.currentTarget.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const newTime = (x / rect.width) * duration;
            onSeek(newTime);
          }}
        />

        <div className="absolute bottom-4 inset-x-0 flex justify-between px-10 text-[10px] text-slate-500 font-black mono pointer-events-none tracking-widest uppercase opacity-40">
          <span>00:00</span>
          <span>{formatTimeShort(duration)}</span>
        </div>
      </div>

      <div className="bg-slate-900/60 border border-white/5 rounded-3xl p-5 shadow-inner backdrop-blur-md">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3 pr-4 border-r border-white/10">
            <div className="w-2.5 h-2.5 rounded-full bg-indigo-500 animate-pulse shadow-[0_0_10px_rgba(99,102,241,0.6)]"></div>
            <div className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.4em] whitespace-nowrap">Chronometric Index</div>
          </div>
          <div className="flex-1 overflow-x-auto no-scrollbar scroll-smooth">
            <div className="flex items-center gap-4 py-1">
              {milestones.length > 0 ? milestones.map((item, idx) => (
                <React.Fragment key={idx}>
                  <div className="flex items-center gap-2 whitespace-nowrap">
                    <span className="text-[11px] font-black text-slate-300 mono">{item.time}</span>
                    <span className="text-[11px] font-bold text-slate-500">{item.label}</span>
                  </div>
                  {idx < milestones.length - 1 && (
                    <span className="text-slate-700 text-[8px] font-black mx-1 opacity-50">●</span>
                  )}
                </React.Fragment>
              )) : (
                <span className="text-[11px] font-black text-slate-600 uppercase tracking-widest animate-pulse">Syncing semantic markers...</span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Timeline;
