
import React from 'react';
import { AudioSegment } from '../types';
import { ICONS } from '../constants';

interface MetadataPanelProps {
  segment: AudioSegment | null;
}

const MetadataPanel: React.FC<MetadataPanelProps> = ({ segment }) => {
  if (!segment) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-slate-500 bg-slate-800/20 rounded-xl border border-dashed border-slate-700 p-8 text-center">
        <ICONS.Archive className="w-12 h-12 mb-4 opacity-20" />
        <h3 className="text-lg font-medium mb-1">No Segment Selected</h3>
        <p className="text-sm">Click a marker on the timeline or list to view semantic details.</p>
      </div>
    );
  }

  const formatTime = (seconds: number) => {
    return new Date(seconds * 1000).toISOString().substr(14, 5);
  };

  return (
    <div className="h-full bg-slate-900/40 border border-slate-700/50 rounded-xl p-6 overflow-y-auto space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
      <header className="space-y-2">
        <div className="flex items-center gap-2">
            <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold tracking-wider
                ${segment.category === 'music' ? 'bg-emerald-500/20 text-emerald-400' : 
                  segment.category === 'speech' ? 'bg-amber-500/20 text-amber-400' : 
                  'bg-slate-500/20 text-slate-400'}`}
            >
                {segment.category}
            </span>
            <div className="flex items-center text-slate-500 text-xs mono">
                <ICONS.Clock className="w-3 h-3 mr-1" />
                {formatTime(segment.startTime)} — {formatTime(segment.endTime)}
            </div>
            <div className="ml-auto text-xs text-slate-500">
                Confidence: {Math.round(segment.confidence * 100)}%
            </div>
        </div>
        <h2 className="text-2xl font-bold text-white">{segment.label}</h2>
      </header>

      <div className="grid grid-cols-1 gap-6">
        <section className="space-y-3">
          <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest">Ethnomusicological Audit</h4>
          <div className="grid grid-cols-2 gap-4">
            {segment.metadata.performer && (
              <div>
                <label className="block text-[10px] text-slate-500 uppercase font-black">Performer</label>
                <div className="text-slate-200 font-bold">{segment.metadata.performer}</div>
              </div>
            )}
            {segment.metadata.tuneType && (
              <div>
                <label className="block text-[10px] text-slate-500 uppercase font-black">Tune Type</label>
                <div className="text-emerald-400 font-bold italic">{segment.metadata.tuneType}</div>
              </div>
            )}
            {segment.metadata.meter && (
              <div>
                <label className="block text-[10px] text-slate-500 uppercase font-black">Meter</label>
                <div className="text-slate-200 font-mono">{segment.metadata.meter}</div>
              </div>
            )}
            {segment.metadata.tempo && (
              <div>
                <label className="block text-[10px] text-slate-500 uppercase font-black">Tempo</label>
                <div className="text-slate-200 font-mono">{segment.metadata.tempo}</div>
              </div>
            )}
          </div>

          {segment.metadata.instruments && segment.metadata.instruments.length > 0 && (
            <div className="pt-2">
              <label className="block text-[10px] text-slate-500 uppercase font-black mb-2">Instrumentation</label>
              <div className="flex flex-wrap gap-2">
                {segment.metadata.instruments.map(inst => (
                  <span key={inst} className="px-3 py-1 rounded-full bg-slate-800 text-slate-300 text-[10px] font-black uppercase tracking-tighter border border-slate-700">
                    {inst}
                  </span>
                ))}
              </div>
            </div>
          )}
        </section>

        <section className="space-y-3">
          <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest">Geographical & Archival Context</h4>
          <div className="space-y-4">
            {segment.metadata.region && (
              <div>
                <label className="block text-[10px] text-slate-500 uppercase font-black">Region/Origin</label>
                <div className="text-slate-200">{segment.metadata.region}</div>
              </div>
            )}
            {segment.metadata.context && (
              <div>
                <label className="block text-[10px] text-slate-500 uppercase font-black">Internal Notes</label>
                <div className="text-slate-300 text-sm leading-relaxed italic">"{segment.metadata.context}"</div>
              </div>
            )}
          </div>
        </section>

        {segment.metadata.evidence && segment.metadata.evidence.length > 0 && (
          <section className="space-y-3 pt-4 border-t border-slate-800">
            <h4 className="text-xs font-bold text-indigo-500 uppercase tracking-widest italic">Acoustic Evidence</h4>
            <ul className="space-y-2">
              {segment.metadata.evidence.map((ev, i) => (
                <li key={i} className="text-xs text-slate-400 flex items-start gap-2">
                  <span className="text-indigo-600 mt-1">●</span>
                  <span>{ev}</span>
                </li>
              ))}
            </ul>
          </section>
        )}

        {segment.metadata.alternatives && segment.metadata.alternatives.length > 0 && (
          <section className="space-y-3 pt-4 border-t border-slate-800">
            <h4 className="text-xs font-bold text-slate-600 uppercase tracking-widest">Alternative Labels</h4>
            <div className="flex flex-wrap gap-2">
              {segment.metadata.alternatives.map(alt => (
                <span key={alt} className="px-2 py-1 rounded bg-slate-800/50 text-slate-500 text-[10px] font-bold border border-slate-700/50">
                  {alt}
                </span>
              ))}
            </div>
          </section>
        )}
      </div>

      <section className="pt-6 border-t border-slate-800">
        <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-3">Segment Narrative</h4>
        <p className="text-slate-200 text-base leading-relaxed font-bold">
          "{segment.metadata.description}"
        </p>
      </section>
    </div>
  );
};

export default MetadataPanel;
